## ------------------------------------------------------------------------
library(msgpack2R)
library(microbenchmark)

x <- as.list(1:1e7)
microbenchmark(xpk <- msgpack_pack(x), times=3) # ~ 0.5 seconds
microbenchmark(xu <- msgpack_unpack(xpk), times=3) # ~ 2.5-3 seconds

