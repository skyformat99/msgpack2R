#' msgpack2R
#' 
#' Package for converting to and from msgpack objects
#' 
#' @docType package
#' @author Travers <traversc@gmail.com>
#' @import Rcpp BH
#' @importFrom Rcpp evalCpp
#' @useDynLib msgpack2R
#' @name msgpack2R
NULL  